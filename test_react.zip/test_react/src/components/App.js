import React from 'react';
// var React = require('react');
//바로 위에 import와 같음

class App extends React.Component {
    render() {
        return (
            <h1>Hello</h1>
        );
    }
}

//ES6
export default App;
// module.export = App;
// ES5를 변화하면 바로 위 주석